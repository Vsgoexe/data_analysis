# Cognifyz Technologies - Data Analysis Internship

**Candidate Name:** Jeevani Vedavendra  
**Reference ID:** CTI/A1/C421603  
**Domain:** Data Analysis  
**Submission Portal:** [Cognifyz Submission Form](https://forms.gle/c3QZCheEySRDPV6V6)  

---

## 📌 Project Overview
This repository contains the complete internship submission for Cognifyz Technologies Data Analysis Internship program. All three levels (**Level 1, Level 2, and Level 3**) covering **11 distinct tasks** have been performed, analyzed, and documented using Python, Pandas, Matplotlib, and Seaborn.

---

## 📁 Repository Structure

```text
├── Dataset .csv                            # Primary restaurant dataset (9,551 records)
├── Data Analysis.pdf                       # Official Cognifyz internship task guidelines
├── Cognifyz_Data_Analysis_Internship_Report.md # Full detailed project report
├── README.md                               # Project documentation and guide
├── scripts/                                # Standalone runnable Python analysis scripts
│   ├── level_1_analysis.py
│   ├── level_2_analysis.py
│   ├── level_3_analysis.py
│   └── generate_notebooks.py
├── notebooks/                              # Jupyter Notebooks (.ipynb)
│   ├── Level_1_Data_Analysis.ipynb
│   ├── Level_2_Data_Analysis.ipynb
│   └── Level_3_Data_Analysis.ipynb
└── outputs/                                # High-resolution visualization charts
    ├── level_1/
    │   ├── top_cuisines.png
    │   ├── city_analysis.png
    │   ├── price_range_distribution.png
    │   └── online_delivery_comparison.png
    ├── level_2/
    │   ├── rating_distribution.png
    │   ├── cuisine_combinations.png
    │   ├── geographic_distribution.png
    │   └── restaurant_chains.png
    └── level_3/
        ├── review_text_analysis.png
        ├── votes_vs_rating.png
        └── price_vs_delivery_booking.png
```

---

## 🚀 Tasks Summary & Highlights

### 🔹 Level 1: Foundations of Restaurant Data
- **Task 1: Top Cuisines**
  - **Top 3 Cuisines:** North Indian (3,960 outlets / 41.46%), Chinese (2,735 outlets / 28.61%), and Fast Food (1,986 outlets / 20.79%).
- **Task 2: City Analysis**
  - **Highest Restaurant Volume:** New Delhi with 5,473 restaurants (57.30% of entire dataset).
  - **Top Average Rating Hubs:** Inner City (4.90), Quezon City (4.80), and Makati City (4.65).
- **Task 3: Price Range Distribution**
  - Budget Tier 1 dominates at **46.53%** (4,444 restaurants), followed by Mid-range Tier 2 at **32.59%** (3,113 restaurants).
- **Task 4: Online Delivery**
  - **25.66%** offer online delivery; restaurants with online delivery maintain an average rating of **3.25** vs. **2.47** for non-delivery restaurants.

### 🔹 Level 2: Advanced Patterns & Spatial Clustering
- **Task 1: Restaurant Ratings**
  - Most common rating category is **3.0 - 3.9 (Good)** accounting for **4,590 restaurants (48.06%)**. Overall mean rating is **2.67**, with an average of **156.91 votes** per restaurant.
- **Task 2: Cuisine Combinations**
  - The leading combination is **North Indian, Chinese** (511 outlets), while specialized pairings (Japanese/Sushi, Thai, Italian) exhibit the highest average ratings (> 4.0).
- **Task 3: Geographic Analysis**
  - Massive spatial density centered in the **Delhi National Capital Region (NCR)**, representing **79.0%** of all geo-tagged restaurants.
- **Task 4: Restaurant Chains**
  - Identified **734 chain brands** managing **2,839 outlets (29.72%)**. Top volume chains include Cafe Coffee Day (83), Domino's Pizza (79), and Subway (63); top rated chains include Chili's (4.58) and Barbeque Nation (4.35).

### 🔹 Level 3: Deep Dives & Statistical Modeling
- **Task 1: Restaurant Reviews**
  - Extracted sentiment keywords: positive descriptors ("Good", "Very Good", "Excellent") describe 47.7% of outlets.
- **Task 2: Votes Analysis**
  - Most voted outlet: **Toit** (Bangalore) with **10,934 votes** (Rating 4.8).
  - Strong positive correlation between popularity (votes) and rating (**r = 0.31 overall, r = 0.41 for rated restaurants, Spearman rho = 0.85**).
- **Task 3: Price Range vs. Online Delivery & Table Booking**
  - Table booking shows exponential growth with price tiers (from **0.02% in Tier 1** to **46.76% in Tier 4**).
  - Online delivery peaks in **Tier 2 (41.31%)** and falls to **9.04% in Tier 4** fine dining.

---

## 🛠️ How to Run the Code

1. **Clone or Extract the Project Directory.**
2. **Install dependencies:**
   ```bash
   pip install pandas numpy matplotlib seaborn scipy
   ```
3. **Execute scripts:**
   ```bash
   python scripts/level_1_analysis.py
   python scripts/level_2_analysis.py
   python scripts/level_3_analysis.py
   ```
4. **View Jupyter Notebooks:**
   Open any `.ipynb` notebook located in the `notebooks/` directory using VS Code, JupyterLab, or Google Colab.
